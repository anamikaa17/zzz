# Portfolio Design Brainstorm - Anamika Mallick

## Design Philosophy Options

### Option 1: Neon Minimalist (Cyberpunk Aesthetic)
**Design Movement:** Cyberpunk/Synthwave with tech-forward minimalism

**Core Principles:**
- High contrast dark backgrounds with vibrant neon accents (cyan, magenta, lime)
- Geometric precision and clean lines
- Emphasis on data visualization and technical credibility
- Minimal text, maximum impact

**Color Philosophy:**
- Primary: Dark navy/charcoal background (#0a0e27)
- Accent 1: Neon cyan (#00d9ff) for primary CTAs and highlights
- Accent 2: Neon magenta (#ff006e) for secondary elements and hover states
- Accent 3: Lime green (#39ff14) for success states and project badges
- Text: Pure white for primary, light gray for secondary
- Emotional intent: Cutting-edge, innovative, tech-savvy

**Layout Paradigm:**
- Asymmetric grid with staggered sections
- Left-aligned hero with floating profile image on right
- Diagonal dividers between sections (using CSS clip-path)
- Horizontal scrolling project cards
- Floating navigation sidebar on left

**Signature Elements:**
- Glowing neon borders on cards and sections
- Animated gradient lines as section dividers
- Pulsing glow effects on interactive elements
- Tech-inspired icons with stroke styling

**Interaction Philosophy:**
- Hover effects trigger neon glow intensification
- Smooth transitions with easing curves
- Cards lift on hover with shadow depth
- Links have animated underlines in neon colors

**Animation:**
- Entrance animations: fade-in with subtle scale (0.95 → 1)
- Hover: glow effect with box-shadow animation
- Scroll: parallax effects on hero section
- Micro-interactions: button press animations with spring easing

**Typography System:**
- Display: "Space Mono" (monospace, bold) for headings - tech aesthetic
- Body: "Inter" (sans-serif, regular) for content - clean readability
- Hierarchy: H1 48px, H2 32px, H3 24px, body 16px
- Letter-spacing: increased on headings for tech feel

---

### Option 2: Elegant Gradient (Modern Professional)
**Design Movement:** Contemporary design with gradient sophistication

**Core Principles:**
- Smooth color gradients creating depth and movement
- Generous whitespace and breathing room
- Soft, approachable aesthetic with professional credibility
- Emphasis on readability and user journey

**Color Philosophy:**
- Primary: Soft white background (#fafbfc)
- Gradient accent: Deep blue to purple (#2563eb → #7c3aed)
- Secondary: Warm accent (#f97316) for CTAs
- Text: Deep charcoal (#1f2937) for primary, medium gray for secondary
- Emotional intent: Trustworthy, innovative, approachable

**Layout Paradigm:**
- Centered hero with full-width gradient background
- Flowing sections with alternating left/right layouts
- Curved dividers between sections using SVG waves
- Card-based project showcase with gradient overlays
- Sticky top navigation with gradient underline

**Signature Elements:**
- Gradient backgrounds on hero and featured sections
- Soft shadow effects (no harsh borders)
- Rounded corners on all cards (24px radius)
- Animated gradient text on main heading

**Interaction Philosophy:**
- Smooth hover states with color transitions
- Subtle scale animations on interactive elements
- Gradient shifts on hover for visual feedback
- Smooth scroll-triggered animations

**Animation:**
- Entrance: fade-in with slide-up motion
- Hover: color shift and subtle scale (1 → 1.02)
- Scroll: fade-in animations triggered at viewport
- Background: subtle gradient animation

**Typography System:**
- Display: "Playfair Display" (serif, elegant) for headings
- Body: "Lato" (sans-serif, warm) for content
- Hierarchy: H1 56px, H2 36px, H3 28px, body 16px
- Letter-spacing: natural, slightly increased on display

---

### Option 3: Dark Academic (Portfolio Classic)
**Design Movement:** Academic/Editorial design with modern twist

**Core Principles:**
- Dark sophisticated background with editorial typography
- Emphasis on content hierarchy and readability
- Classic portfolio structure with contemporary execution
- Refined, timeless aesthetic

**Color Philosophy:**
- Primary: Very dark gray/black background (#111827)
- Accent 1: Warm gold (#f59e0b) for highlights and links
- Accent 2: Slate gray (#64748b) for secondary elements
- Text: Off-white (#f1f5f9) for primary, light gray for secondary
- Emotional intent: Sophisticated, trustworthy, established

**Layout Paradigm:**
- Vertical timeline-inspired layout for experiences
- Two-column layout for projects and skills
- Sticky sidebar navigation on desktop
- Centered content with max-width constraint
- Minimal use of whitespace, content-focused

**Signature Elements:**
- Thin gold accent lines and borders
- Serif typography for headings
- Subtle background patterns (grid or noise)
- Numbered sections for visual organization

**Interaction Philosophy:**
- Understated hover effects with color shifts
- Smooth transitions between states
- Links with animated underlines
- Cards with subtle border highlights on hover

**Animation:**
- Entrance: fade-in with stagger effect for lists
- Hover: color transition and border animation
- Scroll: progressive reveal of content
- Subtle: background texture animation

**Typography System:**
- Display: "Crimson Text" (serif, elegant) for headings
- Body: "Source Sans Pro" (sans-serif, readable) for content
- Hierarchy: H1 52px, H2 32px, H3 24px, body 16px
- Letter-spacing: tight on body, natural on headings

---

## Recommendation

Based on the reference portfolio (which uses neon cyan/dark theme), **Option 1: Neon Minimalist** aligns most closely with the user's preference while being modern and tech-forward. However, all three options are viable depending on the desired impression.

**Which design philosophy do you prefer?**
1. **Neon Minimalist** - Tech-forward, eye-catching, modern
2. **Elegant Gradient** - Professional, approachable, contemporary
3. **Dark Academic** - Sophisticated, timeless, content-focused

Please select one, and I will proceed with full implementation following that design philosophy exactly.
