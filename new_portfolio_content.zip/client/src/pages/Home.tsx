import { useState } from 'react';
import { Menu, X, Github, Linkedin, Mail, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';

/**
 * Neon Minimalist Portfolio Design
 * Design Philosophy: Cyberpunk aesthetic with dark backgrounds, vibrant neon accents
 * Color Palette: Dark navy (#0a0e27), Neon Cyan (#00d9ff), Neon Magenta (#ff006e), Lime Green (#39ff14)
 * Typography: Space Mono for headings (tech feel), Inter for body (readability)
 */

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: 'smooth' });
    setMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
        <div className="container flex justify-between items-center py-4">
          <div className="text-2xl font-bold text-neon-cyan" style={{ fontFamily: 'Space Mono' }}>
            AM
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex gap-8">
            {['Home', 'About', 'Projects', 'Skills', 'Experience', 'Contact'].map((item) => (
              <button
                key={item}
                onClick={() => scrollToSection(item.toLowerCase())}
                className="text-sm font-medium hover:text-neon-cyan transition-colors duration-300"
              >
                {item}
              </button>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden text-neon-cyan"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-card border-t border-border">
            <div className="container py-4 flex flex-col gap-4">
              {['Home', 'About', 'Projects', 'Skills', 'Experience', 'Contact'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className="text-left text-sm font-medium hover:text-neon-cyan transition-colors"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center pt-20">
        <div
          className="absolute inset-0 z-0"
          style={{
            backgroundImage: 'url(/hero-bg.png)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            opacity: 0.3,
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background via-transparent to-background z-0" />

        <div className="container relative z-10 grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="space-y-2">
              <p className="text-neon-cyan text-sm font-mono uppercase tracking-widest">Welcome to my portfolio</p>
              <h1 className="text-5xl md:text-6xl font-bold text-neon-cyan" style={{ fontFamily: 'Space Mono' }}>
                Anamika Mallick
              </h1>
              <p className="text-xl text-muted-foreground">
                AI/ML Enthusiast | Full Stack Developer
              </p>
            </div>

            <p className="text-base text-foreground/80 max-w-lg leading-relaxed">
              Finalist @SIH (Smart India Hackathon) 2025 | B.TECH CSE IOTCSBT | IEEE MTT-S Member | Passionate about Machine Learning, Deep Learning, and building innovative solutions.
            </p>

            <div className="flex gap-4 pt-4">
              <a
                href="#projects"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('projects');
                }}
                className="px-6 py-3 bg-neon-cyan text-background font-semibold rounded hover-neon-glow transition-all duration-300"
              >
                View My Work
              </a>
            </div>

            <div className="flex gap-6 pt-4">
              <a
                href="https://github.com/anamikaa17"
                target="_blank"
                rel="noopener noreferrer"
                className="text-neon-cyan hover:text-neon-magenta transition-colors"
              >
                <Github size={24} />
              </a>
              <a
                href="https://www.linkedin.com/in/anamika-m-01a1a8279?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app"
                target="_blank"
                rel="noopener noreferrer"
                className="text-neon-cyan hover:text-neon-magenta transition-colors"
              >
                <Linkedin size={24} />
              </a>
              <a
                href="mailto:anamikamallick017@gmail.com"
                className="text-neon-cyan hover:text-neon-magenta transition-colors"
              >
                <Mail size={24} />
              </a>
            </div>
          </div>

          <div className="hidden md:flex justify-center">
            <div className="w-64 h-64 rounded-lg neon-border hover-neon-glow transition-all duration-300 overflow-hidden">
              <div className="w-full h-full bg-gradient-to-br from-neon-cyan/20 to-neon-magenta/20 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-6xl mb-4">👩‍💻</div>
                  <p className="text-neon-cyan font-mono text-sm">Anamika Mallick</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 border-t border-border">
        <div className="container">
          <h2 className="text-4xl font-bold text-neon-cyan mb-12" style={{ fontFamily: 'Space Mono' }}>
            About Me
          </h2>

          <div className="grid md:grid-cols-2 gap-12">
            <div className="space-y-6">
              <p className="text-foreground/80 leading-relaxed">
                I'm a passionate developer and AI/ML enthusiast currently pursuing B.Tech in Computer Science and Engineering at Institute of Engineering & Management (IEM), Kolkata. With a focus on Natural Language Processing, Deep Learning, and Full Stack Development, I love building innovative solutions that solve real-world problems.
              </p>
              <p className="text-foreground/80 leading-relaxed">
                As a core member of IEEE MTT-S student chapter, I manage a community of 200+ participants and organize technical workshops. I'm also a volunteer at SheCan Foundation, promoting women in tech and digital literacy.
              </p>
              <p className="text-foreground/80 leading-relaxed">
                My journey in tech has been marked by continuous learning, from internships in NLP and web development to building full-stack applications and deep learning models.
              </p>
            </div>

            <div className="space-y-6">
              <div className="p-6 bg-card rounded neon-border hover-neon-glow transition-all">
                <h3 className="text-neon-cyan font-bold mb-4" style={{ fontFamily: 'Space Mono' }}>Education</h3>
                <div className="space-y-4">
                  <div>
                    <p className="font-semibold text-foreground">B.Tech in Computer Science & Engineering</p>
                    <p className="text-sm text-muted-foreground">Institute of Engineering & Management, Kolkata</p>
                    <p className="text-xs text-neon-cyan mt-1">Expected: August 2028</p>
                  </div>
                </div>
              </div>

              <div className="p-6 bg-card rounded neon-border hover-neon-glow transition-all">
                <h3 className="text-neon-cyan font-bold mb-4" style={{ fontFamily: 'Space Mono' }}>Achievements</h3>
                <ul className="space-y-2 text-sm text-foreground/80">
                  <li className="flex gap-2">
                    <span className="text-neon-lime">▸</span>
                    Finalist @SIH (Smart India Hackathon) 2025
                  </li>
                  <li className="flex gap-2">
                    <span className="text-neon-lime">▸</span>
                    IEEE MTT-S Core Member (May 2025 - Present)
                  </li>
                  <li className="flex gap-2">
                    <span className="text-neon-lime">▸</span>
                    SheCan Foundation Volunteer
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 border-t border-border">
        <div className="container">
          <h2 className="text-4xl font-bold text-neon-cyan mb-12" style={{ fontFamily: 'Space Mono' }}>
            Featured Projects
          </h2>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Project 1: MeloBERT */}
            <div className="group p-6 bg-card rounded neon-border hover-neon-glow hover-lift transition-all duration-300">
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-xl font-bold text-foreground">MeloBERT</h3>
                <ExternalLink size={20} className="text-neon-cyan opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Python, TensorFlow, HuggingFace, NLP
              </p>
              <p className="text-foreground/80 text-sm mb-4">
                Developed a BERT-based neural model for emotion classification in song lyrics. Achieved 65% validation accuracy with attention-based pooling and class weighting.
              </p>
              <div className="flex gap-2 flex-wrap">
                <span className="px-3 py-1 bg-neon-cyan/10 text-neon-cyan text-xs rounded">NLP</span>
                <span className="px-3 py-1 bg-neon-magenta/10 text-neon-magenta text-xs rounded">Deep Learning</span>
                <span className="px-3 py-1 bg-neon-lime/10 text-neon-lime text-xs rounded">Python</span>
              </div>
            </div>

            {/* Project 2: Agrichain */}
            <div className="group p-6 bg-card rounded neon-border hover-neon-glow hover-lift transition-all duration-300">
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-xl font-bold text-foreground">Agrichain Transparency Platform</h3>
                <ExternalLink size={20} className="text-neon-cyan opacity-0 group-hover:opacity-100 transition-opacity" />
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                MongoDB, Node.js, Express.js, JavaScript
              </p>
              <p className="text-foreground/80 text-sm mb-4">
                Multi-role web platform for farmers, retailers, and consumers to track produce movement. Built RESTful APIs with MongoDB integration and role-based dashboards.
              </p>
              <div className="flex gap-2 flex-wrap">
                <span className="px-3 py-1 bg-neon-cyan/10 text-neon-cyan text-xs rounded">Full Stack</span>
                <span className="px-3 py-1 bg-neon-magenta/10 text-neon-magenta text-xs rounded">Backend</span>
                <span className="px-3 py-1 bg-neon-lime/10 text-neon-lime text-xs rounded">Web Dev</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 border-t border-border">
        <div className="container">
          <h2 className="text-4xl font-bold text-neon-cyan mb-12" style={{ fontFamily: 'Space Mono' }}>
            Technical Skills
          </h2>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                category: 'Languages',
                skills: ['Python', 'C/C++', 'JavaScript', 'HTML/CSS'],
              },
              {
                category: 'Frameworks & Libraries',
                skills: ['React', 'Node.js', 'TensorFlow', 'HuggingFace', 'Pandas', 'NumPy'],
              },
              {
                category: 'Domains',
                skills: ['Machine Learning', 'Deep Learning', 'NLP', 'Web Development', 'Full Stack'],
              },
              {
                category: 'Tools & Platforms',
                skills: ['Git/GitHub', 'MongoDB Atlas', 'Google Colab', 'VS Code'],
              },
              {
                category: 'Databases',
                skills: ['MongoDB', 'MySQL', 'Firebase'],
              },
              {
                category: 'Specializations',
                skills: ['Emotion Classification', 'Text Analysis', 'API Development', 'UI/UX'],
              },
            ].map((skillGroup, idx) => (
              <div key={idx} className="p-6 bg-card rounded neon-border hover-neon-glow transition-all">
                <h3 className="text-neon-cyan font-bold mb-4" style={{ fontFamily: 'Space Mono' }}>
                  {skillGroup.category}
                </h3>
                <div className="flex flex-wrap gap-2">
                  {skillGroup.skills.map((skill, i) => (
                    <span
                      key={i}
                      className="px-3 py-1 bg-neon-cyan/10 text-neon-cyan text-xs rounded font-mono"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-20 border-t border-border">
        <div className="container">
          <h2 className="text-4xl font-bold text-neon-cyan mb-12" style={{ fontFamily: 'Space Mono' }}>
            Experience & Volunteering
          </h2>

          <div className="space-y-6">
            {[
              {
                title: 'Core Member, IEEE MTT-S Student Chapter',
                period: 'May 2025 – Present',
                description: 'Managed and coordinated a member base of 200+ participants. Organized technical workshops and sessions on microwave, communication, and wireless technologies.',
              },
              {
                title: 'Volunteer, SheCan Foundation',
                period: 'April 2025 – June 2025',
                description: 'Assisted in conducting women-in-tech outreach programs. Organized training sessions promoting digital literacy and empowerment through technology.',
              },
              {
                title: 'Summer Internship Program - Transfer Learning with NLP',
                period: 'IEM IEDC (8-week program)',
                description: 'Completed intensive training in Transfer Learning techniques and NLP applications, building expertise in modern deep learning approaches.',
              },
            ].map((exp, idx) => (
              <div key={idx} className="p-6 bg-card rounded neon-border hover-neon-glow transition-all">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-lg font-bold text-foreground">{exp.title}</h3>
                  <span className="text-sm text-neon-cyan font-mono">{exp.period}</span>
                </div>
                <p className="text-foreground/80">{exp.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 border-t border-border">
        <div className="container">
          <h2 className="text-4xl font-bold text-neon-cyan mb-12" style={{ fontFamily: 'Space Mono' }}>
            Get In Touch
          </h2>

          <div className="max-w-2xl mx-auto">
            <div className="p-8 bg-card rounded neon-border hover-neon-glow transition-all">
              <p className="text-foreground/80 mb-8">
                I'm always interested in hearing about new projects and opportunities. Feel free to reach out!
              </p>

              <div className="space-y-4">
                <a
                  href="mailto:anamika@example.com"
                  className="flex items-center gap-4 p-4 rounded hover:bg-background/50 transition-colors"
                >
                  <Mail className="text-neon-cyan" size={24} />
                  <div>
                    <p className="font-semibold text-foreground">Email</p>
                    <p className="text-sm text-muted-foreground">anamikamallick017@gmail.com</p>
                  </div>
                </a>

              <a
                href="https://www.linkedin.com/in/anamika-m-01a1a8279?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 p-4 rounded hover:bg-background/50 transition-colors"
              >
                <Linkedin className="text-neon-cyan" size={24} />
                <div>
                  <p className="font-semibold text-foreground">LinkedIn</p>
                  <p className="text-sm text-muted-foreground">linkedin.com/in/anamika-m-01a1a8279</p>
                </div>
              </a>

              <a
                href="https://github.com/anamikaa17"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-4 p-4 rounded hover:bg-background/50 transition-colors"
              >
                <Github className="text-neon-cyan" size={24} />
                <div>
                  <p className="font-semibold text-foreground">GitHub</p>
                  <p className="text-sm text-muted-foreground">github.com/anamikaa17</p>
                </div>
              </a>
              </div>

              <button
                onClick={() => window.location.href = 'mailto:anamikamallick017@gmail.com'}
                className="w-full mt-8 px-6 py-3 bg-neon-cyan text-background font-semibold rounded hover-neon-glow transition-all duration-300"
              >
                Send Me an Email
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-border text-center text-muted-foreground text-sm">
        <div className="container">
          <p>© 2025 Anamika Mallick. All rights reserved.</p>
          <p className="mt-2 text-xs text-muted-foreground/60">Designed with neon aesthetics | Built with React & Tailwind</p>
        </div>
      </footer>
    </div>
  );
}
